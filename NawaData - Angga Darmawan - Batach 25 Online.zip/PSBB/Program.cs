﻿public class Program
{
    public static void Main()
    {
        Console.Write("Input the number of families: ");
        int n = int.Parse(Console.ReadLine());

        Console.Write("Input the number of members in the family (separated by a space): ");
        List<int> familyMembers = Console.ReadLine().Split(' ').Select(int.Parse).ToList();

        if (familyMembers.Count != n)
        {
            Console.WriteLine("Input must be equal with count of family");
            return;
        }

        familyMembers.Sort((a, b) => b.CompareTo(a));

        int bus = 0;
        int i = 0;
        int j = familyMembers.Count - 1;

        while (i <= j)
        {
            if (familyMembers[i] + familyMembers[j] <= 4 && i != j)
            {
                j--;
            }
            bus++;
            i++;
        }

        Console.WriteLine($"Minimum bus required is: {bus}");
    }
}