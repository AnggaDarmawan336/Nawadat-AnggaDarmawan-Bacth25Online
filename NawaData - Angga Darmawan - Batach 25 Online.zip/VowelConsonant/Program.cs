﻿using System;
					
public class Program
{
    // CARA KE SATU SESUAI DENGAN CONTOH YANG DI BERIKAN
    /*
	public string procVowel(string param){
		//your code here
        string vowel = "";
        string vowelChars = "AIUEOaiueo";

        foreach (char c in param){
            if (vowelChars.IndexOf(c) != -1){
                vowel += c;
            }
        }
		return vowel;
	}
	
	public string procConsonant(string param){
		//your code here
        string consonant = "";
        string vowelChars = "AIUEOaiueo";

        foreach (char c in param){
            if (char.IsLetter(c) && vowelChars.IndexOf(c) == -1){
                consonant +=c;
            }
        }
		return consonant;
	}
	
	public static void Main(string[] args)
    {
        Program program = new Program();

        Console.Write("Input one line of words (S) : ");
        string input = Console.ReadLine();
        
        string charVowel = program.procVowel(input);
        string charConsonant = program.procConsonant(input);
        
        Console.WriteLine("Vowel Characters : ");
        Console.WriteLine(charVowel);
        Console.WriteLine("Consonant Characters : ");
        Console.WriteLine(charConsonant);
    }
    */

    public static void Main(string[] args){
        Console.Write("Input one line of words (S) : ");
        string input = Console.ReadLine();
        
        string vowels = "";
        string consonants = "";

        string vowelChars = "AIUEOaiueo";
        
        foreach (char c in input){
            if (vowelChars.IndexOf(c) != -1){
                vowels += c;
            }
            else if (Char.IsLetter(c)){
                consonants += c;
            }
        }
        Console.Write("Vowel Characters : ");
        Console.WriteLine(vowels);
        Console.Write("Consonant Characters : ");
        Console.WriteLine(consonants);
    }
}